import sys,pathlib,unittest,json,hashlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import research
class Tests(unittest.TestCase):
 def setUp(self):self.rows=research.read_json(research.ROOT/'data/reviewed.json')
 def test_schema(self):self.assertEqual(research.validate_rows(self.rows),[])
 def test_ids(self):self.assertEqual([r['id'] for r in self.rows],list(range(1,101)))
 def test_categories(self):self.assertEqual(set(research.metrics(self.rows)['categories'].values()),{10})
 def test_cache(self):
  for row in self.rows:
   for e in row['evidence']:self.assertTrue((research.ROOT/'cache'/(hashlib.sha256(e['url'].encode()).hexdigest()[:20]+'.json')).exists())
 def test_operations_queue(self):
  q=research.read_json(research.ROOT/'data/operations_queue.json')
  self.assertEqual(len(q),100)
  self.assertEqual(sum(bool(a['primary_access_lane_gate']) for a in q),30)
  self.assertTrue(all(a['owner'] is None and a['exit_evidence'] is None for a in q))
 def test_report_criteria_sections(self):
  html=(research.ROOT/'output/index.html').read_text()
  self.assertIn('Category clusters',html)
  self.assertIn('12/30',html)
  self.assertIn('5-app source cross-check',html)
 def test_unsafe_scheme(self):
  for u in ['http://example.com','file:///etc/passwd','https://user:pass@example.com']:
   with self.assertRaises(ValueError):research.public_url(u)
 def test_escape_parser(self):
  p=research.TextOnly();p.feed('<p>good</p><script>bad</script>');self.assertIn('good',p.text());self.assertNotIn('bad',p.text())
 def test_identity(self):self.assertEqual(research.decision(self.rows[83]),'Resolve identity')
 def test_local(self):self.assertEqual(research.decision(self.rows[97]),'Local adapter')
 def test_routing_labels(self):
  self.assertEqual(set(research.metrics(self.rows)['readiness']),{'Prototype path','Validate','Access work','Local adapter','Resolve identity'})
 def test_unknown_allowed(self):self.assertEqual(self.rows[89]['auth_methods'],['Unknown'])
 def test_no_duplicate_urls_count(self):self.assertEqual(research.metrics(self.rows)['evidence_urls'],380)
if __name__=='__main__': unittest.main()
